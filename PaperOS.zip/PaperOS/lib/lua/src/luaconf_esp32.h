/* ESP32 overrides - included via -include flag or manual include */
#define LUA_USE_POSIX 0
#define LUA_USE_DLOPEN 0
#define LUA_NOENV 1
