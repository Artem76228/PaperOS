#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include "../../config.h"

#define PE_MAX_LINES   99
#define PE_LINE_WIDTH  40
#define PE_MAX_LINKS   100
#define PE_MAX_FIELDS   24   // <input>/<button> elements per page
#define PE_MAX_FORMS     6   // <form> elements per page
#define PE_MAX_SELECT  (PE_MAX_LINKS + PE_MAX_FIELDS)  // links+fields, in doc order

enum ParseState { PS_TEXT, PS_TAG, PS_SCRIPT, PS_STYLE, PS_ENTITY, PS_TITLE, PS_TITLE_TAG };

class PaperEngine {
public:
    int  bytesDownloaded = 0;
    int  totalBytes      = 0;
    int  lineCount       = 0;

    // HTTP status of the last fetch(): 200/301/404/etc from the server,
    // or a negative HTTPClient library error (connection refused, timeout...).
    // 0 means fetch() was never called.
    int    lastHttpCode = 0;
    String pageTitle    = "";  // from <title>, empty if page had none

    String linkURLs[PE_MAX_LINKS];
    int    linkCount = 0;

    // --- Forms & input fields --------------------------------------------
    // A tiny subset of HTML forms: text-like <input> elements (and their
    // submit button) become on-screen, selectable fields the same way links
    // are. Checkboxes/radios/file inputs are intentionally not supported -
    // there's no realistic way to represent multi-state controls on this
    // display/input combo, so they're silently skipped rather than shown
    // half-working.
    struct FormInfo {
        String action;      // resolved relative to the page URL when submitted
        bool   isGet = true; // false = <form method="post"> (submitted as GET anyway - see browser.h)
    };
    struct FieldInfo {
        String name;
        String value;
        bool   isSubmit = false;  // type="submit"/"button"/"image"
        int    formId    = -1;    // index into forms[], or -1 if outside any <form>
    };
    FormInfo  forms[PE_MAX_FORMS];
    int       formCount = 0;
    FieldInfo fields[PE_MAX_FIELDS];
    int       fieldCount = 0;

    // Links and fields in the order they actually appear in the document,
    // so ,/ navigation moves through the page the way it looks on screen
    // instead of "all links, then all fields".
    enum SelKind { EK_LINK, EK_FIELD };
    struct SelectableInfo { SelKind kind; int idx; };
    SelectableInfo selectables[PE_MAX_SELECT];
    int            selectableCount = 0;

    void (*onLineReady)(String& line, int lineNum) = nullptr;

    String sessionCookie = "";

    // Maps an HTTP status (or negative HTTPClient error) to a color family -
    // 2xx success, 3xx redirect/warn, 4xx/5xx/connection error - so the UI
    // can show state at a glance instead of just "error / not error".
    static uint16_t codeColor(int code) {
        if (code <= 0)                  return COL_ERR;   // connection-level error
        if (code >= 200 && code < 300)  return COL_OK;
        if (code >= 300 && code < 400)  return COL_WARN;
        return COL_ERR;                                    // 4xx/5xx
    }

    // Human-readable text for an HTTP status or HTTPClient error code,
    // so the browser can show "Error 404: Not Found" instead of nothing.
    static String httpCodeText(int code) {
        switch (code) {
            case 200: return "OK";
            case 201: return "Created";
            case 202: return "Accepted (likely bot-check/challenge page)";
            case 204: return "No Content";
            case 301: return "Moved Permanently";
            case 302: return "Found (redirect)";
            case 303: return "See Other";
            case 304: return "Not Modified";
            case 307: return "Temporary Redirect";
            case 308: return "Permanent Redirect";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 403: return "Forbidden";
            case 404: return "Not Found";
            case 405: return "Method Not Allowed";
            case 408: return "Request Timeout";
            case 429: return "Too Many Requests";
            case 500: return "Internal Server Error";
            case 502: return "Bad Gateway";
            case 503: return "Service Unavailable";
            case 504: return "Gateway Timeout";
            case HTTPC_ERROR_CONNECTION_REFUSED:  return "Connection refused";
            case HTTPC_ERROR_SEND_HEADER_FAILED:   return "Send header failed";
            case HTTPC_ERROR_SEND_PAYLOAD_FAILED:  return "Send payload failed";
            case HTTPC_ERROR_NOT_CONNECTED:        return "Not connected";
            case HTTPC_ERROR_CONNECTION_LOST:      return "Connection lost";
            case HTTPC_ERROR_NO_STREAM:            return "No stream";
            case HTTPC_ERROR_NO_HTTP_SERVER:       return "No HTTP server";
            case HTTPC_ERROR_TOO_LESS_RAM:         return "Not enough RAM";
            case HTTPC_ERROR_ENCODING:             return "Bad encoding";
            case HTTPC_ERROR_STREAM_WRITE:         return "Stream write error";
            case HTTPC_ERROR_READ_TIMEOUT:         return "Connection timed out";
            default:
                if (code < 0)   return "Connection error";
                if (code >= 300 && code < 400) return "Redirect (not followed)";
                if (code >= 400 && code < 500) return "Client error";
                if (code >= 500)               return "Server error";
                return "Unknown error";
        }
    }

    void reset() {
        _line      = "";
        lineCount  = 0;
        linkCount  = 0;
        fieldCount = 0;
        formCount  = 0;
        selectableCount = 0;
        _curForm      = -1;
        _activeLinkId = -1;
        _state     = PS_TEXT;
        _tag       = "";
        _entity    = "";
        _endTag    = "";
        _lastSpace = false;
        _titleBuf  = "";
        pageTitle  = "";
    }

    bool fetch(const String& url,
               const String& referer = "",
               int timeoutMs = 60000,
               void (*progress)(int, int) = nullptr)
    {
        // Redirects are followed by hand, one hop at a time, instead of via
        // HTTPClient's own setFollowRedirects(). Reason: we pass an explicit
        // WiFiClient/WiFiClientSecure into http.begin(client, url) so we can
        // pick plain vs TLS per-request (see below) - but once you hand
        // HTTPClient an explicit client object, it keeps using that same
        // object for any redirect it follows internally, even if the
        // Location: header crosses from http:// to https:// or back. A
        // WiFiClientSecure doing a raw (non-TLS) HTTP exchange, or a plain
        // WiFiClient suddenly fed a TLS handshake, both fail - which is
        // exactly the "works on https, breaks on http" pattern this fixes.
        String curURL = url;
        int    code   = 0;

        for (int hop = 0; hop <= 5; hop++) {
            // Real fix for the -1 / -11 "random" failures on plain http://
            // sites (example.com, httpbin.org, ...): the old code always
            // used WiFiClientSecure, which always performs a TLS handshake
            // regardless of scheme. Against a server that only speaks plain
            // HTTP on that port, that handshake either gets reset instantly
            // (HTTPC_ERROR_CONNECTION_REFUSED, -1) or hangs until timeout
            // (HTTPC_ERROR_READ_TIMEOUT, -11), depending on how that
            // particular server/proxy reacts to receiving TLS bytes on a
            // plain port. Picking the transport by scheme avoids both.
            bool isHttps = curURL.startsWith("https://");

            WiFiClientSecure secureClient;
            WiFiClient       plainClient;
            if (isHttps) secureClient.setInsecure();
            WiFiClient& client = isHttps ? static_cast<WiFiClient&>(secureClient)
                                          : plainClient;
            client.setTimeout(timeoutMs / 1000);

            HTTPClient http;
            http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);  // we do it ourselves, see above
            http.setTimeout(timeoutMs);

            if (!http.begin(client, curURL)) { lastHttpCode = code ? code : -1; return false; }

            const char* hdrKeys[] = { "Set-Cookie", "Content-Encoding", "Location" };
            http.collectHeaders(hdrKeys, 3);

            // A custom UA token (the old "...PaperOS/1.0" suffix) and missing
            // Accept/Accept-Language headers are exactly what bot-detection on
            // sites like DuckDuckGo flags (hence the 202 "please wait" replies).
            // This mimics a real mobile Chrome request as closely as this
            // HTTP client allows.
            http.addHeader("Accept-Encoding", "identity");
            http.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            http.addHeader("Accept-Language", "en-US,en;q=0.9");
            http.addHeader("User-Agent",
                "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
            if (sessionCookie != "")
                http.addHeader("Cookie", sessionCookie);
            // Real browsers keep sending the *original* referring page across
            // a redirect chain, not the intermediate redirect URL, so this
            // stays the same on every hop.
            if (referer.length() > 0)
                http.addHeader("Referer", referer);

            code = http.GET();
            if (http.hasHeader("Set-Cookie"))
                sessionCookie = http.header("Set-Cookie");

            bool isRedirect = (code >= 300 && code < 400) && http.hasHeader("Location");
            if (!isRedirect) {
                lastHttpCode = code;
                if (code != 200) { http.end(); return false; }

                totalBytes = http.getSize();
                if (totalBytes <= 0) totalBytes = 1;

                reset();

                WiFiClient* stream = http.getStreamPtr();
                bytesDownloaded = 0;
                uint32_t t0 = millis();

                _fetchPlain(stream, http, timeoutMs, t0, progress);

                _flushLine();
                http.end();
                return lineCount > 0;
            }

            String location = http.header("Location");
            http.end();

            String next = _resolveURL(curURL, location);
            if (next.length() == 0 || next == curURL) { lastHttpCode = code; return false; }
            curURL = next;
        }

        lastHttpCode = code;  // too many redirects - report the last hop's code
        return false;
    }

private:
    ParseState _state     = PS_TEXT;
    String     _line      = "";
    String     _tag       = "";
    String     _entity    = "";
    String     _endTag    = "";
    bool       _lastSpace = false;
    String     _titleBuf  = "";

    // Id of the <a> we're currently inside, or -1. Real pages sometimes wrap
    // block elements inside a link, or the link text is simply long enough
    // to word-wrap - either way the color marker byte was only written once,
    // at the *start* of the link, so a line break (from either _flushLine()
    // or the width-based wrap in _addChar()) would otherwise leave the
    // continuation rendered as plain unhighlighted text even though it's
    // still part of the link. Re-emitting the marker at the top of each new
    // line while this is set fixes that.
    int _activeLinkId = -1;

    // Index into forms[] while inside a <form>...</form>, else -1.
    int _curForm = -1;

    // Resolves a possibly-relative redirect target (Location: header) against
    // the URL that was just fetched. Mirrors Browser::_resolveURL() in
    // browser.h (same rules for absolute / protocol-relative / rooted /
    // same-directory paths) - duplicated rather than shared because the
    // engine has no dependency on the Browser class, and this is small
    // enough that a shared header isn't worth the coupling.
    static String _resolveURL(const String& base, const String& rel) {
        if (rel.startsWith("http"))  return rel;
        if (rel.startsWith("//"))    return "https:" + rel;
        if (rel.startsWith("/")) {
            int p3 = base.indexOf("://");
            if (p3 < 0) return rel;
            int sl = base.indexOf('/', p3 + 3);
            if (sl < 0) return base + rel;
            return base.substring(0, sl) + rel;
        }
        int last = base.lastIndexOf('/');
        if (last > 7) return base.substring(0, last + 1) + rel;
        return base + "/" + rel;
    }

    // Generic quoted/unquoted attribute grab, e.g. _getAttr(tag, "href").
    // Case-sensitive on the attribute name (matches the existing href
    // handling below) - real-world markup is overwhelmingly lowercase here.
    static String _getAttr(const String& tag, const char* name) {
        String key = String(name) + "=";
        int idx = tag.indexOf(key);
        while (idx > 0 && tag[idx - 1] != ' ' && tag[idx - 1] != '\t' && tag[idx - 1] != '\n') {
            idx = tag.indexOf(key, idx + 1);
        }
        if (idx == -1) return "";
        int vstart = idx + key.length();
        if (vstart >= (int)tag.length()) return "";
        char q = tag[vstart];
        if (q == '"' || q == '\'') {
            int vend = tag.indexOf(q, vstart + 1);
            if (vend == -1) return "";
            return tag.substring(vstart + 1, vend);
        }
        int vend = vstart;
        while (vend < (int)tag.length() && tag[vend] != ' ' && tag[vend] != '>') vend++;
        return tag.substring(vstart, vend);
    }

    void _fetchPlain(WiFiClient* s, HTTPClient& h,
                     int tms, uint32_t t0, void (*prog)(int,int))
    {
        uint8_t buf[512];
        int noData = 0;
        while (h.connected() && millis() - t0 < (uint32_t)tms) {
            if (ESP.getFreeHeap() < 15000 || lineCount >= PE_MAX_LINES) break;
            int avail = s->available();
            if (avail > 0) {
                noData = 0;
                int n = s->read(buf, min((int)sizeof(buf), avail));
                if (n > 0) {
                    bytesDownloaded += n;
                    if (prog) prog(bytesDownloaded, totalBytes);
                    for (int i = 0; i < n && lineCount < PE_MAX_LINES; i++)
                        _processChar((char)buf[i]);
                }
            } else {
                if (++noData > 1000) break;
                delay(1);
            }
        }
    }

    void _processChar(char c) {
        switch (_state) {
        case PS_TEXT:
            if (c == '<') { _state = PS_TAG; _tag = ""; }
            else if (c == '&') { _state = PS_ENTITY; _entity = ""; }
            else if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
                if (!_lastSpace && _line.length() > 0) { _addChar(' '); _lastSpace = true; }
            } else { _addChar(c); _lastSpace = false; }
            break;

        case PS_TAG:
            if (c == '>') { _handleTag(); }
            else { if (_tag.length() < 180) _tag += c; }
            break;

        case PS_SCRIPT:
            _endTag += c;
            if (_endTag.length() > 9) _endTag.remove(0, 1);
            if (_endTag.equalsIgnoreCase("</script>")) { _endTag = ""; _state = PS_TEXT; }
            break;

        case PS_STYLE:
            _endTag += c;
            if (_endTag.length() > 11) _endTag.remove(0, 1);
            if (_endTag.endsWith(">")) {
                String lo = _endTag; lo.toLowerCase();
                if (lo.endsWith("</style>") || lo.endsWith("</svg>") ||
                    lo.endsWith("</noscript>") || lo.endsWith("</head>")) {
                    _state = PS_TEXT; _endTag = "";
                }
            }
            break;

        // Collects <title>...</title> text into pageTitle, separately from
        // the rendered body, so the browser can show a real page title.
        case PS_TITLE:
            if (c == '<') { _state = PS_TITLE_TAG; _endTag = "<"; }
            else if (_titleBuf.length() < 60) _titleBuf += c;
            break;

        case PS_TITLE_TAG:
            _endTag += c;
            if (c == '>') {
                if (_endTag.equalsIgnoreCase("</title>")) {
                    pageTitle = _titleBuf; pageTitle.trim();
                    _state = PS_TEXT;
                } else {
                    _state = PS_TITLE;  // some other tag inside <title>, ignore it
                }
                _endTag = "";
            }
            break;

        case PS_ENTITY:
            if (c == ';') { _decodeEntity(_entity); _state = PS_TEXT; }
            else if (c == ' ' || _entity.length() > 8) {
                _state = PS_TEXT; _addChar('&');
                for (int i = 0; i < (int)_entity.length(); i++) _addChar(_entity[i]);
                _addChar(c);
            } else { _entity += c; }
            break;
        }
    }

    void _handleTag() {
        String base = _tag;
        int sp = base.indexOf(' ');
        if (sp != -1) base = base.substring(0, sp);
        base.toLowerCase();

        if (base == "script") { _state = PS_SCRIPT; _endTag = ""; }
        else if (base == "title") { _state = PS_TITLE; _endTag = ""; _titleBuf = ""; }
        else if (base == "style" || base == "svg" || base == "noscript") {
            // Note: "head" is intentionally NOT swallowed whole anymore -
            // <title> lives inside it and needs to be reached individually.
            // Other head children (meta/link/base) carry no visible text,
            // so nothing extra leaks into the rendered page.
            _state = PS_STYLE; _endTag = "";
        } else {
            _state = PS_TEXT;
            if (base == "a") {
                int hIdx = _tag.indexOf("href=");
                if (hIdx != -1) {
                    int q = _tag.indexOf('"', hIdx);
                    if (q == -1) q = _tag.indexOf('\'', hIdx);
                    if (q != -1) {
                        int qe = _tag.indexOf(_tag[q], q + 1);
                        if (qe != -1 && linkCount < PE_MAX_LINKS && selectableCount < PE_MAX_SELECT) {
                            linkURLs[linkCount] = _tag.substring(q + 1, qe);
                            _addMarkerPair('\x01', (char)(linkCount + 32));
                            _activeLinkId = linkCount;
                            selectables[selectableCount++] = { EK_LINK, linkCount };
                            linkCount++;
                        }
                    }
                }
            } else if (base == "/a") {
                _addChar('\x02');
                _activeLinkId = -1;
            }
            else if (base == "br" || base == "p" || base == "div" || base == "tr") { _flushLine(); }
            else if (base == "li") { _flushLine(); _line += " * "; }
            else if (base == "h1" || base == "h2" || base == "h3") { _flushLine(); _line += "[H] "; }
            else if (base == "form") {
                if (formCount < PE_MAX_FORMS) {
                    String method = _getAttr(_tag, "method"); method.toLowerCase();
                    forms[formCount].action = _getAttr(_tag, "action");
                    forms[formCount].isGet  = (method != "post");
                    _curForm = formCount;
                    formCount++;
                } else {
                    _curForm = -1;
                }
            }
            else if (base == "/form") { _curForm = -1; }
            else if (base == "input" || base == "button") {
                String type = _getAttr(_tag, "type"); type.toLowerCase();
                if (type == "" && base == "button") type = "submit";
                if (type == "") type = "text";
                bool isSubmit  = (type == "submit" || type == "button" || type == "image");
                bool isHidden  = (type == "hidden");
                bool isUnsupported = (type == "checkbox" || type == "radio" ||
                                      type == "file" || type == "reset");
                String name  = _getAttr(_tag, "name");
                String value = _getAttr(_tag, "value");

                if (isHidden) {
                    // Not shown, not selectable - just rides along on submit.
                    if (fieldCount < PE_MAX_FIELDS) {
                        fields[fieldCount++] = { name, value, false, _curForm };
                    }
                } else if (!isUnsupported && fieldCount < PE_MAX_FIELDS &&
                           selectableCount < PE_MAX_SELECT) {
                    int fid = fieldCount;
                    fields[fieldCount] = { name, isSubmit ? "" : value, isSubmit, _curForm };
                    _addMarkerPair('\x03', (char)(fid + 32));
                    String label = isSubmit ? (value.length() > 0 ? value : String("Submit"))
                                             : (value.length() > 0 ? value : String("..."));
                    if (label.length() > 12) label = label.substring(0, 12);
                    _addChar('[');
                    for (int k = 0; k < (int)label.length(); k++) _addChar(label[k]);
                    _addChar(']');
                    _addChar('\x04');
                    selectables[selectableCount++] = { EK_FIELD, fid };
                    fieldCount++;
                }
            }
        }
    }


    void _decodeEntity(const String& ent) {
        if (ent.startsWith("#")) {
            int code = ent.startsWith("#x")
                ? strtol(ent.substring(2).c_str(), NULL, 16)
                : ent.substring(1).toInt();
            if (code >= 1040 && code <= 1087)      { _addChar(0xD0); _addChar(0x90 + (code - 1040)); }
            else if (code >= 1088 && code <= 1103) { _addChar(0xD1); _addChar(0x80 + (code - 1088)); }
            else if (code == 1025) { _addChar(0xD0); _addChar(0x81); }
            else if (code == 1105) { _addChar(0xD1); _addChar(0x91); }
            else if (code > 31 && code < 127) _addChar((char)code);
        } else {
            if      (ent == "nbsp") _addChar(' ');
            else if (ent == "lt")   _addChar('<');
            else if (ent == "gt")   _addChar('>');
            else if (ent == "amp")  _addChar('&');
            else if (ent == "quot") _addChar('"');
            else if (ent == "apos") _addChar('\'');
            // Typographic entities mapped to plain-ASCII lookalikes - the
            // display font only carries ASCII + Cyrillic glyphs, so real
            // Unicode dashes/quotes would just render as boxes.
            else if (ent == "mdash" || ent == "ndash") { _addChar('-'); }
            else if (ent == "hellip") { _addChar('.'); _addChar('.'); _addChar('.'); }
            else if (ent == "laquo" || ent == "raquo" ||
                     ent == "ldquo" || ent == "rdquo") { _addChar('"'); }
            else if (ent == "lsquo" || ent == "rsquo") { _addChar('\''); }
            else if (ent == "times")  _addChar('x');
            else if (ent == "copy")   _addChar('c');
            else if (ent == "reg")    _addChar('r');
            else if (ent == "bull")   _addChar('*');
        }
    }

    void _addChar(char c) {
        if (lineCount >= PE_MAX_LINES) return;
        _line += c;
        if ((int)_line.length() > PE_LINE_WIDTH) {
            int sp = _line.lastIndexOf(' ');
            if (sp > 0) {
                String part = _line.substring(0, sp);
                String cont = _line.substring(sp + 1);
                if (onLineReady) onLineReady(part, lineCount);
                lineCount++;
                _line = "";
                if (_activeLinkId >= 0 && lineCount < PE_MAX_LINES) {
                    _line += '\x01';
                    _line += (char)(_activeLinkId + 32);
                }
                _line += cont;
            } else {
                _flushLine();
            }
        }
    }

    // Atomically inserts a 2-byte marker (color-escape + id), used for both
    // link-open ('\x01') and field ('\x03') markers. Going through _addChar
    // twice for this used to risk the id byte landing on a different
    // display line than its marker byte if a wrap fell between the two
    // calls, corrupting the highlight; this instead forces a line break
    // *before* the pair if it wouldn't otherwise fit, so the two bytes are
    // always written to the same _line together.
    void _addMarkerPair(char marker, char id) {
        if (lineCount >= PE_MAX_LINES) return;
        if ((int)_line.length() + 2 > PE_LINE_WIDTH) _flushLine();
        if (lineCount >= PE_MAX_LINES) return;
        _line += marker;
        _line += id;
    }

    void _flushLine() {
        if (_line.length() == 0 || lineCount >= PE_MAX_LINES) return;
        if (onLineReady) onLineReady(_line, lineCount);
        lineCount++;
        _line = "";
        _lastSpace = true;
        // See _activeLinkId's comment: keep a link's highlight going across
        // block-level breaks (<br>/<p>/<div>/<tr>) that land inside it.
        if (_activeLinkId >= 0 && lineCount < PE_MAX_LINES) {
            _line += '\x01';
            _line += (char)(_activeLinkId + 32);
        }
    }
};