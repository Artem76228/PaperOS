#pragma once

#define OS_NAME        "PaperOS"
#define OS_VERSION     "1.0"
#define OS_AUTHOR      "Artem76228"

#define SCREEN_W       240
#define SCREEN_H       135
#define HEADER_H       16
#define FOOTER_H       14
#define CONTENT_Y      (HEADER_H + 1)
#define CONTENT_H      (SCREEN_H - HEADER_H - FOOTER_H - 1)

// --- "Windows 95" palette --------------------------------------------------
// Every app pulls its colors from these macros (header/footer/dialogs via
// OsUI, plus their own list/content drawing), so retheming them here
// reskins the whole OS at once instead of touching every app individually.
// RGB565 values below are the classic Win95 default scheme converted from
// its real 24-bit RGB (button face 192,192,192; title navy 0,0,128; etc).
#define COL_BG         0xFFFF  // window/client area background - white
#define COL_BG2        0xC618  // dialog / button-face gray
#define COL_TEXT       0x0000  // black
#define COL_DIM        0x8410  // 3D-shadow gray, used for secondary text
#define COL_ACCENT     0x0010  // navy - titlebar/selection blue
#define COL_SELECTED   0x0010  // navy - selected item highlight
#define COL_WARN       0xFD20
#define COL_ERR        0xF800
#define COL_OK         0x0400  // Win95 dark "OK" green

#define COL_HEADER     0x0010  // active titlebar - navy
#define COL_HEADER_BAD 0x8000  // maroon - disconnected / error state titlebar
#define COL_HEADER_WARN 0xA260  // dark amber - used for 3xx/redirect-not-followed
#define COL_HEADER_LOAD 0x8410  // gray - "inactive window" look while connecting
#define COL_FOOTER     0xC618  // status bar face gray
#define COL_FIELD      0xF81F  // magenta - form input placeholders, distinct from link accent

// Win95 3D bevel shades (light top/left edge, dark bottom/right edge)
#define COL_BEVEL_HI    0xFFFF  // highlight (white)
#define COL_BEVEL_LO    0x8410  // shadow (mid gray)
#define COL_BEVEL_DKLO  0x0000  // dark shadow (black), outermost edge
#define COL_DESKTOP     0x0410  // classic teal desktop background

#define NUM_TILE_COLORS 8
static const uint16_t TILE_COLORS[NUM_TILE_COLORS] = {
    0x04FF, 0xF81F, 0xFD20, 0x07E0,
    0xFFE0, 0xA81F, 0x001F, 0xF800,
};

#define TICK_MS        20
#define KEY_REPEAT_MS  120

#define MAX_APPS       20
#define MAX_WIFI_SLOTS 3

// Feature toggles. All apps are compiled in by default; flip one of these
// to 0 to drop it from the binary if flash/RAM ever gets tight.
#define PAPEROS_ENABLE_BROWSER  1
#define PAPEROS_ENABLE_EDITOR3D 1
#define PAPEROS_ENABLE_MYAI     1
#define PAPEROS_ENABLE_MUSIC    1
#define PAPEROS_ENABLE_LUA      1
