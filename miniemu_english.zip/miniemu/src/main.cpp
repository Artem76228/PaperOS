// ─────────────────────────────────────────────────────────────────────
//  PaperEMU — NES + GBC/GB for M5Cardputer (PaperOS)
//
//  Launch from AdvanceOS/PaperOS:
//    1. OS writes app/RomToLoad = "/Games/rom.nes"
//    2. OS writes app/BootTo = 7
//    3. OS flashes MiniEMU.extension to OTA -> esp_restart()
//    4. MiniEMU boots -> reads RomToLoad -> launches the ROM directly
//    5. Exit (G0 1s) -> writes app/BootTo=7 -> esp_restart()
//    6. OS boots, sees BootTo=7 -> opens Games
//
//  Standalone launch (no OS):
//    Offers the last game or shows the file list on the SD card
// ─────────────────────────────────────────────────────────────────────

#include <M5Cardputer.h>
#include "cardputer/SdService.h"
#include "share/paperemu_display.h"
#include "vfs/vfs_xip.h"
#include "vfs/rom_flash_io.h"
#include "vfs/rom_xip.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "nes/run_nes.h"
#include "gbc/run_gbc.h"
#include "last_game.h"     // Preferences + signalQuitToOs
#include "select_rom.h"    // getRomType, RomType enum

#include "esp_task_wdt.h"
#include "share/input.h"
#include "share/emu_log_cpp.h"
#include "share/paperemu_ui.h"
#include "share/video_mode.h"

void setup() {
    vTaskPrioritySet(NULL, 19);

#ifdef DISABLE_WATCHDOGS
    esp_task_wdt_deinit();
    disableCore0WDT();
    disableCore1WDT();
    esp_task_wdt_delete(NULL);
#endif

    auto cfg = M5.config();
    cfg.output_power = true;
    M5Cardputer.begin(cfg);

    SdService sd;
    paperemu_display::init();

    // Wait for the SD card
    while (!sd.begin()) {
        paperemu_ui::drawStatusBox("PaperEMU", "Insert SD card");
        delay(800);
    }

    std::string romPath; // always /sd/Games/rom.nes (for fopen via VFS)
    bool fromOs = false;

    // -- 1. Launched from the OS: app/RomToLoad is non-empty --------------
    romPath = getRomFromOsLaunch();
    if (!romPath.empty()) {
        fromOs = true;
        EMU_LOG("OS launch: %s\n", romPath.c_str());
        // Check the file exists (isFile takes a path without /sd)
        std::string sdRelPath = romPath;
        if (sdRelPath.rfind("/sd", 0) == 0) sdRelPath = sdRelPath.substr(3);
        if (!sd.isFile(sdRelPath)) {
            paperemu_ui::drawStatusBox("PaperEMU", "ROM not found");
            delay(2000);
            restartToPaperOS();
        }
    }
    // -- 2. Cold start with no ROM (boot stayed on the emulator) -----------
    else {
        paperemu_ui::drawWaitScreen("Open from PaperOS Games");
        while (true) {
            M5Cardputer.update();
            if (M5Cardputer.BtnA.pressedFor(1000)) {
                restartToPaperOS();
            }
            delay(20);
        }
    }

    if (romPath.empty()) {
        restartToPaperOS();
    }

    EMU_LOG("ROM path: %s\n", romPath.c_str());

    // -- Copy the ROM into the SPIFFS partition for XIP --------------------
    paperemu_ui::drawWaitScreen("Loading ROM...");

    const esp_partition_t* romPart = findRomPartition("romxip");
    if (!romPart) {
        while (1) {
            paperemu_ui::drawStatusBox("PaperEMU", "No romxip partition");
            delay(1500);
        }
    }

    size_t romSize = 0;
    if (!copyFileToPartition(romPath.c_str(), romPart, &romSize,
                             paperemu_ui::drawCopyProgress, nullptr)) {
        while (1) {
            paperemu_ui::drawStatusBox("PaperEMU", "ROM too large (~5MB max)");
            delay(1500);
        }
    }

    paperemu_display::flushInput(10);

    if (xip_map_rom_partition("romxip", romSize) != 0) {
        while (1) {
            paperemu_ui::drawStatusBox("PaperEMU", "XIP map failed");
            delay(1500);
        }
    }

    vfs_xip_register();

    // -- Detect ROM type -----------------------------------------------------
    auto ext = getRomType(romPath);

    if (ext != ROM_TYPE_NES && ext != ROM_TYPE_GB) {
        paperemu_ui::drawStatusBox("PaperEMU", "Only .nes .gb .gbc");
        delay(2500);
        restartToPaperOS();
    }

    paperemu_ui::drawWaitScreen("Any key = play");
    uint32_t t = millis();
    int tip = 0;
    for (;;) {
        if (paperemu_display::readChar() != KEY_NONE) break;
        if (millis() - t >= 3000) {
            t = millis();
            paperemu_ui::drawHintOnly(tip % 2 == 0 ? "Any key = play"
                                                   : "` menu  G0 = PaperOS");
            tip++;
        }
        delay(1);
    }

    // -- Remember the last game ----------------------------------------------
    saveLastGameToNvs(romPath);

    auto pos = romPath.find_last_of("/\\");
    std::string romName = (pos == std::string::npos) ? romPath : romPath.substr(pos + 1);

    EMU_LOG("Free heap: %u\n", esp_get_free_heap_size());

    // -- Launch the emulator --------------------------------------------------
    if (ext == ROM_TYPE_NES) {
        share::setActiveCore(share::Core::NES);
        std::string xipName = "/xip/" + romName;
        run_nes(xipName.c_str());
    }
    else { // ROM_TYPE_GB - covers both GBC and GB
        share::setActiveCore(share::Core::GBC);
        run_gbc(get_rom_ptr(), get_rom_size(), romName.c_str());
    }

    // -- Exit the emulator -> back to PaperOS ---------------------------------
    restartToPaperOS();
}

void loop() {
    // The emulator blocks here - loop() is not used
}
