#pragma once

namespace paperemu_ui {
// Saves the current display frame to /shots/shotNNN.bmp. Returns the path or "".
const char* saveDisplayScreenshot();
}
