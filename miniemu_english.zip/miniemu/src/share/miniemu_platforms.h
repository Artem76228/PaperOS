#pragma once
// GameStation / MiniEMU platforms - built into the firmware or loaded
// via .extension from the SD card
struct MiniEmuPlatform {
    const char* name;
    const char* exts;
    bool        inThisBuild;
};

static const MiniEmuPlatform MINIEMU_PLATFORMS[] = {
    {"NES",       ".nes",              true},
    {"Game Boy",  ".gb .gbc",          true},
    {"SMS/GG",    ".sms .gg .sg",      false},
    {"Genesis",   ".md .gen .bin",     false},
    {"SNES",      ".smc .sfc",         false},
    {"Atari 2600",".a26",              false},
    {"Atari 7800",".a78",              false},
    {"Lynx",      ".lnx",              false},
    {"NGP",       ".ngp .ngc",         false},
    {"PCE",       ".pce",              false},
    {"MSX",       ".rom .mx1 .mx2",    false},
    {"WonderSwan",".ws .wsc",          false},
    {"GX4000",    ".cpr",              false},
};
static const int MINIEMU_PLATFORM_COUNT = sizeof(MINIEMU_PLATFORMS) / sizeof(MINIEMU_PLATFORMS[0]);
