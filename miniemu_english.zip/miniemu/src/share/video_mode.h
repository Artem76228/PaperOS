#pragma once
// Single point of control for aspect ratio/zoom on the active core.
// The underlying switches (fullscreenMode/nesZoomPercent for NES,
// gbcFullScreen/gbcZoomPercent for GBC) already existed in the engine.
// The single entry point is the "Aspect Ratio" item in the pause menu.

namespace share {

enum class Core { NONE, NES, GBC };

void setActiveCore(Core c);
void cycleAspectRatio();
const char* aspectRatioLabel();

}  // namespace share
