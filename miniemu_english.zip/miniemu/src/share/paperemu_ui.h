#pragma once
#include <M5Cardputer.h>
#include <cstring>
#include <cstdio>
#include "paperos_colors.h"
#include "video_mode.h"

// PaperEMU UI - emulator interface in the PaperOS style.
//
// Everything is drawn into an offscreen LGFX_Sprite and pushed with a
// single pushSprite(0, 0) per frame.

namespace paperemu_ui {

// std::clamp is C++17, and the toolchain doesn't build with gnu++17, so
// this uses its own clamp helper.
inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

inline LGFX_Sprite& canvas() {
    static LGFX_Sprite s(&M5Cardputer.Display);
    static bool inited = false;
    if (!inited) {
        s.setColorDepth(16);
        s.createSprite(PE_SCREEN_W, PE_SCREEN_H);
        s.setTextSize(1);
        s.setFont(&fonts::Font0);
        inited = true;
    }
    return s;
}

inline void drawHeader(LGFX_Sprite& d, const char* title) {
    d.fillRect(0, 0, PE_SCREEN_W, PE_HEADER_H, POS_COL_HEADER);

    // Battery indicator - matches PaperOS's own OsUI
    int bat = clampi((int)map(M5Cardputer.Power.getBatteryVoltage(), 3300, 4200, 0, 100), 0, 100);
    const int BX = 218, BY = 4;
    d.drawRect(BX, BY, 18, 8, 0xCE59);
    d.fillRect(BX + 18, BY + 2, 2, 4, 0xCE59);
    int bw = map(bat, 0, 100, 0, 16);
    uint16_t bcol = bat > 30 ? POS_COL_OK : (bat > 15 ? POS_COL_WARN : POS_COL_ERR);
    if (bw > 0) d.fillRect(BX + 1, BY + 1, bw, 6, bcol);

    char buf[32];
    strncpy(buf, title, 31);
    buf[31] = '\0';
    d.setClipRect(4, 0, 200, PE_HEADER_H);
    d.setTextColor(WHITE, POS_COL_HEADER);
    d.setCursor(6, 4);
    d.print(buf);
    d.clearClipRect();
}

inline void drawFooter(LGFX_Sprite& d, const char* hint) {
    d.fillRect(0, PE_SCREEN_H - PE_FOOTER_H, PE_SCREEN_W, PE_FOOTER_H, POS_COL_FOOTER);
    d.drawFastHLine(0, PE_SCREEN_H - PE_FOOTER_H, PE_SCREEN_W, POS_COL_ACCENT);
    char buf[44];
    strncpy(buf, hint, 42);
    buf[42] = '\0';
    d.setTextColor(POS_COL_DIM, POS_COL_FOOTER);
    d.setCursor(4, PE_SCREEN_H - PE_FOOTER_H + 3);
    d.print(buf);
}

// Waiting screen shown before the ROM starts
inline void drawWaitScreen(const char* hint) {
    auto& d = canvas();
    d.fillSprite(POS_COL_BG);
    drawHeader(d, "PaperEMU");
    d.fillRect(8, 20, PE_SCREEN_W - 16, 88, POS_COL_BG2);
    d.drawRect(8, 20, PE_SCREEN_W - 16, 88, POS_COL_ACCENT);
    d.setTextColor(POS_COL_ACCENT, POS_COL_BG2);
    d.setCursor(88, 36);
    d.print("PaperEMU");
    d.setTextColor(POS_COL_DIM, POS_COL_BG2);
    d.setCursor(52, 52);
    d.print("PaperOS  NES  GB  GBC");
    d.fillRect(12, 72, PE_SCREEN_W - 24, 12, POS_COL_BG2);
    d.setTextColor(POS_COL_TEXT, POS_COL_BG2);
    d.setCursor(12, 74);
    {
        char buf[36];
        strncpy(buf, hint ? hint : "", 35);
        buf[35] = '\0';
        d.print(buf);
    }
    drawFooter(d, ";.e/s nav  ENT play  Fn+S pic  G0 OS");
    d.pushSprite(0, 0);
}

inline void drawHintOnly(const char* hint) {
    auto& d = canvas();
    d.fillRect(12, 72, PE_SCREEN_W - 24, 12, POS_COL_BG2);
    d.setTextColor(POS_COL_TEXT, POS_COL_BG2);
    d.setCursor(12, 74);
    char buf[36];
    strncpy(buf, hint ? hint : "", 35);
    buf[35] = '\0';
    d.print(buf);
    d.pushSprite(0, 0);
}

inline void drawStatusBox(const char* title, const char* msg) {
    auto& d = canvas();
    d.fillSprite(POS_COL_BG);
    drawHeader(d, title);
    d.fillRect(8, 24, PE_SCREEN_W - 16, 72, POS_COL_BG2);
    d.drawRect(8, 24, PE_SCREEN_W - 16, 72, POS_COL_ACCENT);
    d.setTextColor(POS_COL_TEXT, POS_COL_BG2);
    d.setCursor(12, 48);
    char buf[34];
    strncpy(buf, msg ? msg : "", 33);
    buf[33] = '\0';
    d.print(buf);
    drawFooter(d, "");
    d.pushSprite(0, 0);
}

inline void _drawBar(LGFX_Sprite& d, int x, int y, int w, int h, int percent) {
    d.drawRect(x, y, w, h, POS_COL_DIM);
    int fillW = clampi((w - 2) * percent / 100, 0, w - 2);
    d.fillRect(x + 1, y + 1, w - 2, h - 2, POS_COL_BG2);
    if (fillW > 0) d.fillRect(x + 1, y + 1, fillW, h - 2, POS_COL_ACCENT);
}

// ROM copy progress into the SPIFFS partition (replaces CardputerView::copyProgress)
inline void drawCopyProgress(size_t total, size_t current, void* /*userCtx*/ = nullptr) {
    static uint32_t lastDraw = 0;
    uint32_t now = millis();
    if (now - lastDraw < 60 && current != total) return;
    lastDraw = now;

    auto& d = canvas();
    d.fillSprite(POS_COL_BG);
    drawHeader(d, "PaperEMU");

    float ratio = (total > 0) ? (float)current / (float)total : 0.0f;
    ratio = clampf(ratio, 0.0f, 1.0f);

    d.fillRect(8, 24, PE_SCREEN_W - 16, 72, POS_COL_BG2);
    d.drawRect(8, 24, PE_SCREEN_W - 16, 72, POS_COL_ACCENT);
    d.setTextColor(POS_COL_TEXT, POS_COL_BG2);
    d.setCursor(16, 40);
    d.print("Loading ROM...");

    const int barX = 16, barY = 60, barW = PE_SCREEN_W - 32, barH = 16;
    _drawBar(d, barX, barY, barW, barH, (int)(ratio * 100));

    char pct[8];
    snprintf(pct, sizeof(pct), "%d%%", (int)(ratio * 100));
    d.setTextColor(POS_COL_DIM, POS_COL_BG2);
    d.setCursor(16, 82);
    d.print(pct);

    drawFooter(d, "");
    d.pushSprite(0, 0);
}

// -- Pause menu --------------------------------------------------------

enum PauseItem {
    PI_CONTINUE = 0,
    PI_BRIGHTNESS,
    PI_VOLUME,
    PI_ASPECT,
    PI_SCREENSHOT,
    PI_EXIT,
    PI_COUNT
};

struct PauseMenuState {
    int sel = 0;
    int brightness = 128;
    int volume = 128;
    char toast[36] = "";
    uint32_t toastUntil = 0;
};

inline void drawPauseMenu(const PauseMenuState& st) {
    auto& d = canvas();
    d.fillSprite(POS_COL_BG);
    drawHeader(d, "PaperEMU - Menu");

    static const char* labels[PI_COUNT] = {
        "Continue",
        "Brightness",
        "Volume",
        "Aspect Ratio",
        "Screenshot (SD)",
        "Exit to PaperOS",
    };

    const int rowH = 17;
    const int top  = PE_CONTENT_Y + 1;

    for (int i = 0; i < PI_COUNT; i++) {
        int y = top + i * rowH;
        bool sel = (i == st.sel);
        uint16_t bg = sel ? POS_COL_SELECTED : POS_COL_BG;
        uint16_t fg = sel ? WHITE : POS_COL_TEXT;

        d.fillRect(4, y, PE_SCREEN_W - 8, rowH - 2, bg);
        d.setTextColor(fg, bg);
        d.setCursor(10, y + 5);
        d.print(labels[i]);

        if (i == PI_BRIGHTNESS) {
            int pct = clampi(st.brightness * 100 / 255, 0, 100);
            _drawBar(d, 130, y + 3, 80, 10, pct);
        } else if (i == PI_VOLUME) {
            int pct = clampi(st.volume * 100 / 255, 0, 100);
            _drawBar(d, 130, y + 3, 80, 10, pct);
        } else if (i == PI_ASPECT) {
            d.setTextColor(sel ? WHITE : POS_COL_ACCENT, bg);
            d.setCursor(150, y + 5);
            d.print(share::aspectRatioLabel());
        }
    }

    if (st.toast[0] && millis() < st.toastUntil) {
        d.fillRect(20, PE_SCREEN_H - PE_FOOTER_H - 20, PE_SCREEN_W - 40, 16, POS_COL_BG2);
        d.drawRect(20, PE_SCREEN_H - PE_FOOTER_H - 20, PE_SCREEN_W - 40, 16, POS_COL_ACCENT);
        d.setTextColor(POS_COL_OK, POS_COL_BG2);
        d.setCursor(24, PE_SCREEN_H - PE_FOOTER_H - 16);
        d.print(st.toast);
    }

    drawFooter(d, ";.e/s nav  ,//a/d -/+  ENT ok  `= back");
    d.pushSprite(0, 0);
}

}  // namespace paperemu_ui
