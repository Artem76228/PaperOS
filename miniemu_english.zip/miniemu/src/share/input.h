#pragma once
#include <M5Cardputer.h>

#define CARDPUTER_LEFT_1       'a'
#define CARDPUTER_LEFT_2       ','

#define CARDPUTER_RIGHT_1      'd'
#define CARDPUTER_RIGHT_2      '/'

#define CARDPUTER_UP_1         'e'
#define CARDPUTER_UP_2         ';'

#define CARDPUTER_DOWN_1       's'
#define CARDPUTER_DOWN_2       '.'
#define CARDPUTER_DOWN_3       'z'

#define CARDPUTER_BTN_A_1      'l'
#define CARDPUTER_BTN_A_2      'j'

#define CARDPUTER_BTN_B        'k'

#define CARDPUTER_BTN_START    '1'
#define CARDPUTER_BTN_SELECT   '2'

// Aspect ratio/zoom is switched ONLY from the pause menu
// (` -> Aspect Ratio -> ENT).

// Volume - the only hotkeys that work during gameplay without pausing,
// and don't overlap with any other key.
#define CARDPUTER_VOL_UP_1          '='     // Volume +
#define CARDPUTER_VOL_DOWN_1        '-'     // Volume -

// Brightness is intentionally left out of the in-game hotkeys: the
// "[" / "]" keys physically ghost with "e" on the Cardputer's keyboard
// matrix. Brightness is now adjusted only from the pause menu (`), where
// gameplay input is guaranteed not to be read at the same time.

extern uint32_t lastPadState;

namespace share
{
    bool shouldPollInput(); 
    void checkCommonInput(const Keyboard_Class::KeysState& status);

    // I2C PAD (M5Stack JoyV2 or Joystick v1.1)
    void detectI2cPad();
    bool hasI2cPad();
    uint32_t pollI2cPad();

    // Bitmask
    enum PadBits : uint32_t {
        PAD_UP      = 1u << 0,
        PAD_DOWN    = 1u << 1,
        PAD_LEFT    = 1u << 2,
        PAD_RIGHT   = 1u << 3,
        PAD_A       = 1u << 4,
        PAD_B       = 1u << 5,
        PAD_START   = 1u << 6,
        PAD_SELECT  = 1u << 7,
    };
}
