#pragma once
// Replaces CardputerView::initialize() / CardputerInput without the
// GameStation menu system - just what PaperEMU actually needs: display
// bus setup and key reading.
#include <M5Cardputer.h>

#define KEY_OK          '\n'
#define KEY_DEL         '\b'
#define KEY_ESC_CUSTOM  '`'
#define KEY_NONE        '\0'

namespace paperemu_display {

// Display SPI overclock + rotation + DMA (formerly CardputerView::initialize())
inline void init() {
    auto* Display = &M5Cardputer.Display;

    auto* panel = Display->panel();
    if (panel) {
        auto* bus = (lgfx::Bus_SPI*)panel->bus();
        if (bus) {
            auto bcfg = bus->config();
            bcfg.freq_write  = 80000000;  // 80 MHz
            bcfg.freq_read   = 20000000;
            bcfg.dma_channel = 1;
            bus->config(bcfg);
        }
        auto pcfg = panel->config();
        pcfg.bus_shared = false;
        panel->config(pcfg);
    }

    Display->setRotation(1);
    Display->setTextDatum(top_left);
    Display->setFont(&fonts::Font0);
}

// Reads a single character (replaces CardputerInput::readChar())
inline char readChar() {
    M5Cardputer.update();
    if (!M5Cardputer.Keyboard.isChange() || !M5Cardputer.Keyboard.isPressed()) return KEY_NONE;

    auto status = M5Cardputer.Keyboard.keysState();
    for (auto c : status.word) return c;
    if (status.enter) return KEY_OK;
    if (status.del)   return KEY_DEL;
    return KEY_NONE;
}

// Replaces CardputerInput::flushInput()
inline void flushInput(size_t ms) {
    uint32_t start = millis();
    while (millis() - start < ms) {
        M5Cardputer.update();
        auto status = M5Cardputer.Keyboard.keysState();
        status.reset();
        delay(1);
    }
}

}  // namespace paperemu_display
