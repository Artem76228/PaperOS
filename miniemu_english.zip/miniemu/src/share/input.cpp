#include "input.h"

#include <algorithm>
#include <cstring>
#include <esp_sleep.h>
#include <esp_system.h>
#include "game_save.h"
#include <Preferences.h>
#include "../last_game.h"
#include "paperemu_display.h"
#include "paperos_colors.h"
#include "paperemu_ui.h"
#include "screenshot.h"

static uint32_t s_lastInputUs = 0;
uint32_t lastPadState = 0xFFFFFFFF;
static const uint32_t INPUT_POLL_PERIOD_MS = 32;
constexpr int64_t INPUT_POLL_PERIOD_US = 1000 * INPUT_POLL_PERIOD_MS;

enum I2cPadType : uint8_t {
    I2C_PAD_NONE = 0,
    I2C_PAD_JOYV2,
    I2C_PAD_JOYV1_1,
};
static I2cPadType s_i2cPadType = I2C_PAD_NONE;

static constexpr uint8_t JOYSTICK_CENTER   = 128;
static constexpr uint8_t JOYSTICK_DEADZONE = 25;
static constexpr int CARDPUTER_I2C_SCL = 1;
static constexpr int CARDPUTER_I2C_SDA = 2;

static constexpr uint8_t JOYSTICK2_ADDR                = 0x63;
static constexpr uint8_t JOYSTICK2_ADC_VALUE_8BITS_REG = 0x10;
static constexpr uint8_t JOYSTICK2_BUTTON_REG          = 0x20;
static constexpr uint8_t JOYSTICK1_ADDR = 0x52;

namespace share
{
   bool shouldPollInput()
    {
        uint32_t now = esp_timer_get_time();
        if (now - s_lastInputUs < INPUT_POLL_PERIOD_US) {
            return false;
        }
        s_lastInputUs = now;
        return true;
    }

    static inline bool key(char c) {
        return M5Cardputer.Keyboard.isKeyPressed(c);
    }

    static void waitEscReleased() {
        while (M5Cardputer.Keyboard.isKeyPressed(KEY_ESC_CUSTOM)) {
            M5Cardputer.update();
            delay(10);
        }
        delay(40);
    }

    static int adjustVolume(int delta) {
        int v = M5Cardputer.Speaker.getVolume();
        v = (delta > 0) ? std::min(v + 12, 255) : std::max(v - 12, 0);
        M5Cardputer.Speaker.setVolume(v);
        return v;
    }

    static int adjustBrightness(int delta) {
        int b = M5Cardputer.Display.getBrightness();
        b = (delta > 0) ? std::min(b + 16, 255) : std::max(b - 16, 8);
        M5Cardputer.Display.setBrightness(b);
        return b;
    }

    // Volume hotkey usable during gameplay (no pause needed) - the only
    // key pair that doesn't overlap with anything else (see input.h).
    static void handleInGameVolumeKeys() {
        if (key(CARDPUTER_VOL_UP_1))   adjustVolume(+1);
        if (key(CARDPUTER_VOL_DOWN_1)) adjustVolume(-1);
    }

    static void showToast(paperemu_ui::PauseMenuState& st, const char* msg) {
        strncpy(st.toast, msg, sizeof(st.toast) - 1);
        st.toast[sizeof(st.toast) - 1] = '\0';
        st.toastUntil = millis() + 1800;
    }

    static bool captureScreenshot(paperemu_ui::PauseMenuState& st) {
        const char* path = paperemu_ui::saveDisplayScreenshot();
        if (!path || !path[0]) {
            showToast(st, "SD save failed");
            return false;
        }
        char shortMsg[36];
        const char* base = strrchr(path, '/');
        base = base ? base + 1 : path;
        snprintf(shortMsg, sizeof(shortMsg), "OK %s", base);
        showToast(st, shortMsg);
        return true;
    }

    static void showPauseMenu() {
        waitEscReleased();

        paperemu_ui::PauseMenuState st;
        st.brightness = M5Cardputer.Display.getBrightness();
        st.volume = M5Cardputer.Speaker.getVolume();

        bool dirty = true;
        bool wasEnter = false;
        uint32_t lastNav = 0;
        uint32_t lastAdjust = 0;

        auto redrawIfNeeded = [&]() {
            if (st.toast[0] && millis() >= st.toastUntil) {
                st.toast[0] = '\0';
                dirty = true;
            }
            if (!dirty) return;
            paperemu_ui::drawPauseMenu(st);
            dirty = false;
        };

        redrawIfNeeded();

        while (true) {
            M5Cardputer.update();
            auto ks = M5Cardputer.Keyboard.keysState();

            // Up/down navigation through menu items
            if (millis() - lastNav > 160) {
                bool nav = false;
                if (key(';') || key('e')) {
                    st.sel = (st.sel + paperemu_ui::PI_COUNT - 1) % paperemu_ui::PI_COUNT;
                    nav = true;
                } else if (key('.') || key('s')) {
                    st.sel = (st.sel + 1) % paperemu_ui::PI_COUNT;
                    nav = true;
                }
                if (nav) {
                    lastNav = millis();
                    dirty = true;
                }
            }

            // Left/right adjusts the selected item (paused, so gameplay
            // input isn't read here - no conflict with the D-pad)
            if (millis() - lastAdjust > 90) {
                bool left  = key(',') || key('a');
                bool right = key('/') || key('d');
                if (left || right) {
                    int dir = right ? +1 : -1;
                    switch (st.sel) {
                        case paperemu_ui::PI_BRIGHTNESS:
                            st.brightness = adjustBrightness(dir);
                            dirty = true;
                            break;
                        case paperemu_ui::PI_VOLUME:
                            st.volume = adjustVolume(dir);
                            dirty = true;
                            break;
                        case paperemu_ui::PI_ASPECT:
                            share::cycleAspectRatio();
                            dirty = true;
                            break;
                        default:
                            break;
                    }
                    lastAdjust = millis();
                }
            }

            if ((ks.enter || key('o')) && !wasEnter) {
                wasEnter = true;
                switch (st.sel) {
                    case paperemu_ui::PI_CONTINUE:
                        while (M5Cardputer.Keyboard.keysState().enter) {
                            M5Cardputer.update();
                            delay(10);
                        }
                        delay(40);
                        return;
                    case paperemu_ui::PI_ASPECT:
                        share::cycleAspectRatio();
                        dirty = true;
                        break;
                    case paperemu_ui::PI_SCREENSHOT:
                        captureScreenshot(st);
                        dirty = true;
                        break;
                    case paperemu_ui::PI_EXIT:
                        restartToPaperOS();
                        break;
                    default:
                        break;
                }
            }
            if (!ks.enter && !key('o')) {
                wasEnter = false;
            }

            if (ks.fn && key('s')) {
                captureScreenshot(st);
                dirty = true;
                delay(200);
            }

            if (M5Cardputer.BtnA.pressedFor(1000)) {
                restartToPaperOS();
            }

            if (st.toast[0] && millis() < st.toastUntil) {
                dirty = true;
            }

            redrawIfNeeded();
            delay(20);
        }
    }

    static bool s_pauseOpen = false;

    void checkCommonInput(const Keyboard_Class::KeysState& status)
    {
        if (!s_pauseOpen &&
            M5Cardputer.Keyboard.isChange() &&
            M5Cardputer.Keyboard.isKeyPressed(KEY_ESC_CUSTOM)) {
            s_pauseOpen = true;
            showPauseMenu();
            s_pauseOpen = false;
            return;
        }

        if (M5Cardputer.BtnA.pressedFor(1000)) {
            restartToPaperOS();
        }

        handleInGameVolumeKeys();

        if (status.fn && key('s')) {
            paperemu_ui::saveDisplayScreenshot();
            delay(120);
        }
    }

    void detectI2cPad()
    {
        Wire.begin(CARDPUTER_I2C_SDA, CARDPUTER_I2C_SCL);
        Wire.setClock(400000);

        Wire.beginTransmission(JOYSTICK2_ADDR);
        if (Wire.endTransmission() == 0) {
            s_i2cPadType = I2C_PAD_JOYV2;
            printf("[INPUT] M5 Unit JoyV2 detected at 0x%02X (SDA=%d, SCL=%d)\n",
                   JOYSTICK2_ADDR, CARDPUTER_I2C_SDA, CARDPUTER_I2C_SCL);
            return;
        }

        Wire.beginTransmission(JOYSTICK1_ADDR);
        if (Wire.endTransmission() == 0) {
            s_i2cPadType = I2C_PAD_JOYV1_1;
            printf("[INPUT] M5 Unit Joystick v1.1 detected at 0x%02X (SDA=%d, SCL=%d)\n",
                   JOYSTICK1_ADDR, CARDPUTER_I2C_SDA, CARDPUTER_I2C_SCL);
            return;
        }

        s_i2cPadType = I2C_PAD_NONE;
        printf("[INPUT] No I2C joystick found (SDA=%d, SCL=%d)\n",
               CARDPUTER_I2C_SDA, CARDPUTER_I2C_SCL);

        Wire.end();
    }

    bool hasI2cPad()
    {
        return s_i2cPadType != I2C_PAD_NONE;
    }

    static bool joystick2_read_xy(uint8_t& x, uint8_t& y)
    {
        Wire.beginTransmission(JOYSTICK2_ADDR);
        Wire.write(JOYSTICK2_ADC_VALUE_8BITS_REG);
        if (Wire.endTransmission(false) != 0) {
            return false;
        }

        if (Wire.requestFrom(JOYSTICK2_ADDR, (uint8_t)2) != 2) {
            return false;
        }

        x = Wire.read();
        y = Wire.read();
        return true;
    }

    static bool joystick2_read_button(uint8_t& btn)
    {
        Wire.beginTransmission(JOYSTICK2_ADDR);
        Wire.write(JOYSTICK2_BUTTON_REG);
        if (Wire.endTransmission(false) != 0) {
            return false;
        }

        if (Wire.requestFrom(JOYSTICK2_ADDR, (uint8_t)1) != 1) {
            return false;
        }

        btn = Wire.read();
        return true;
    }

    static bool joystick1_read_all(uint8_t& x, uint8_t& y, uint8_t& btn)
    {
        if (Wire.requestFrom(JOYSTICK1_ADDR, (uint8_t)3) != 3) {
            return false;
        }

        x   = Wire.read();
        y   = Wire.read();
        btn = Wire.read();
        return true;
    }

    uint32_t pollI2cPad()
    {
        if (s_i2cPadType == I2C_PAD_NONE) {
            return 0;
        }

        uint8_t x8 = 0;
        uint8_t y8 = 0;
        uint8_t btnRaw = 1;

        if (s_i2cPadType == I2C_PAD_JOYV2) {
            if (!joystick2_read_xy(x8, y8)) return 0;
            joystick2_read_button(btnRaw);
        } else {
            if (!joystick1_read_all(x8, y8, btnRaw)) return 0;
            x8 = 255 - x8;
        }

        uint32_t state = 0;

        if (x8 < (JOYSTICK_CENTER - JOYSTICK_DEADZONE)) {
            state |= PAD_RIGHT;
        } else if (x8 > (JOYSTICK_CENTER + JOYSTICK_DEADZONE)) {
            state |= PAD_LEFT;
        }

        if (y8 < (JOYSTICK_CENTER - JOYSTICK_DEADZONE)) {
            state |= PAD_DOWN;
        } else if (y8 > (JOYSTICK_CENTER + JOYSTICK_DEADZONE)) {
            state |= PAD_UP;
        }

        if (btnRaw == 0x00) {
            state |= PAD_A;
        }

        return state;
    }
}
