#pragma once
// PaperOS colors and layout (RGB565), matching src/config.h 1:1 so the
// emulator menus look like a native OS app rather than a separate theme.
#define POS_COL_BG       0x0820
#define POS_COL_BG2      0x1082
#define POS_COL_TEXT     0xEF7D
#define POS_COL_DIM      0x7BEF
#define POS_COL_ACCENT   0x07FF
#define POS_COL_SELECTED 0x03EF
#define POS_COL_WARN     0xFD20
#define POS_COL_ERR      0xF800
#define POS_COL_OK       0x07E0
#define POS_COL_HEADER   0x0410
#define POS_COL_FOOTER   0x10A2

#define PE_SCREEN_W   240
#define PE_SCREEN_H   135
#define PE_HEADER_H   16
#define PE_FOOTER_H   14
#define PE_CONTENT_Y  (PE_HEADER_H + 1)
