#include "video_mode.h"
#include <cstdio>

// NES (nes_osd.c)
extern "C" {
extern bool fullscreenMode;
extern int  nesZoomPercent;
}

// GBC (gbc_display.cpp)
extern bool gbcFullScreen;
extern int  gbcZoomPercent;

namespace share {

static Core s_core = Core::NONE;

void setActiveCore(Core c) {
    s_core = c;
}

void cycleAspectRatio() {
    if (s_core == Core::NES) {
        if (!fullscreenMode) {
            fullscreenMode = true;
            nesZoomPercent = 100;
        } else {
            nesZoomPercent += 10;
            if (nesZoomPercent > 150) {
                nesZoomPercent = 100;
                fullscreenMode = false;
            }
        }
    } else if (s_core == Core::GBC) {
        if (!gbcFullScreen) {
            gbcFullScreen  = true;
            gbcZoomPercent = 100;
        } else {
            gbcZoomPercent += 10;
            if (gbcZoomPercent > 150) {
                gbcZoomPercent = 100;
                gbcFullScreen  = false;
            }
        }
    }
}

const char* aspectRatioLabel() {
    static char buf[20];
    if (s_core == Core::NES) {
        if (!fullscreenMode) return "Original 4:3";
        snprintf(buf, sizeof(buf), "Full %d%%", nesZoomPercent);
        return buf;
    }
    if (s_core == Core::GBC) {
        if (!gbcFullScreen) return "Original 1:1";
        snprintf(buf, sizeof(buf), "Full %d%%", gbcZoomPercent);
        return buf;
    }
    return "-";
}

}  // namespace share
