#pragma GCC optimize ("Os")
#pragma once

#include <string>
#include <Preferences.h>
#include <esp_ota_ops.h>
#include <esp_system.h>
#include "share/game_save.h"
#include "share/miniemu_platforms.h"

// ─────────────────────────────────────────────────────────────────────
//  PaperOS <-> PaperEMU handoff via NVS (namespace "app")
//
//  PaperOS -> emulator (before ESP.restart):
//    RomToLoad   "/games/rom.nes"   SD path without the /sd prefix
//    BootTo      7                  open Games after returning
//    + esp_ota_set_boot_partition(ota_1)
//
//  Emulator -> PaperOS (G0 or Exit menu):
//    BootTo      7
//    + esp_ota_set_boot_partition(ota_0)  <- required, otherwise it boots
//      straight back into the emulator
//
//  SD: /games/PaperEMU.extension  + ROM (.nes .gb .gbc)
// ─────────────────────────────────────────────────────────────────────

#define PAPEROS_BOOT_GAMES  7
#define BOOT_GAMES          PAPEROS_BOOT_GAMES

static inline void signalQuitToOs() {
    Preferences appPrefs;
    appPrefs.begin("app", false);
    appPrefs.putInt("BootTo", PAPEROS_BOOT_GAMES);
    appPrefs.end();

    Preferences emuPrefs;
    emuPrefs.begin("cardputer_emu", false);
    emuPrefs.putBool("quit_game", true);
    emuPrefs.end();
}

static inline void restartToPaperOS() {
    signalQuitToOs();
    const esp_partition_t* running = esp_ota_get_running_partition();
    const esp_partition_t* osPart  = esp_ota_get_next_update_partition(running);
    if (osPart) {
        esp_ota_set_boot_partition(osPart);
    }
    while (share::gameIsSaving()) {
        delay(1);
    }
    esp_restart();
}

// -- ROM from PaperOS ------------------------------------------------------
static inline std::string getRomFromOsLaunch() {
    Preferences prefs;
    prefs.begin("app", false);
    String v = prefs.getString("RomToLoad", "");
    if (!v.isEmpty()) {
        prefs.putString("RomToLoad", "");
    }
    prefs.end();

    if (v.isEmpty()) return "";

    std::string path = v.c_str();
    if (path.rfind("/sd/", 0) == 0) return path;
    if (path.rfind("/sd", 0) == 0 && path.size() > 3 && path[3] == '/') return path;
    if (path[0] == '/') return "/sd" + path;
    return "/sd/" + path;
}

static inline void saveLastGameToNvs(const std::string& filePath) {
    if (filePath.empty()) return;
    std::string clean = filePath;
    if (clean.rfind("/sd/", 0) == 0) clean = clean.substr(3);

    Preferences prefs;
    prefs.begin("cardputer_emu", false);
    prefs.putString("last_game", clean.c_str());
    prefs.end();
}
