#pragma GCC optimize ("Os")

#include "run_nes.h"

#include <M5Cardputer.h>
#include <stdio.h>
#include <string>

void run_nes(const char* xipPath)
{
  // The display is already configured once in main.cpp
  // (paperemu_display::init()) - no need to reinitialize here.

  // Call the NES core
  // Note: the core expects argv to be the ROM path
  char* argv_[1] = { const_cast<char*>(xipPath) };
  nofrendo_main(1, argv_);
}
