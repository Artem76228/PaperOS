#include "screenshot.h"
#include <SD.h>
#include <stdio.h>
#include <M5Cardputer.h>

namespace paperemu_ui {

static char s_lastPath[40];

const char* saveDisplayScreenshot() {
    s_lastPath[0] = '\0';

    if (!SD.exists("/PaperOS")) {
        SD.mkdir("/PaperOS");
    }
    if (!SD.exists("/PaperOS/shots")) {
        SD.mkdir("/PaperOS/shots");
    }

    char path[32];
    int idx = 0;
    do {
        snprintf(path, sizeof(path), "/PaperOS/shots/shot%03d.bmp", idx++);
    } while (SD.exists(path) && idx < 999);

    File f = SD.open(path, FILE_WRITE);
    if (!f) return "";

    const int W = 240;
    const int H = 135;
    int rowSize = ((W * 3 + 3) & ~3);
    int pixelDataSize = rowSize * H;
    int fileSize = 54 + pixelDataSize;

    uint8_t hdr[54] = {};
    hdr[0] = 'B';
    hdr[1] = 'M';
    *(int32_t*)(hdr + 2) = fileSize;
    *(int32_t*)(hdr + 10) = 54;
    *(int32_t*)(hdr + 14) = 40;
    *(int32_t*)(hdr + 18) = W;
    *(int32_t*)(hdr + 22) = H;
    *(int16_t*)(hdr + 26) = 1;
    *(int16_t*)(hdr + 28) = 24;
    *(int32_t*)(hdr + 34) = pixelDataSize;
    f.write(hdr, 54);

    uint8_t* row = (uint8_t*)malloc(rowSize);
    if (!row) {
        f.close();
        return "";
    }

    auto& dsp = M5Cardputer.Display;
    for (int y = H - 1; y >= 0; y--) {
        int pos = 0;
        for (int x = 0; x < W; x++) {
            uint16_t c = dsp.readPixel(x, y);
            row[pos++] = (uint8_t)((c & 0x1F) << 3);
            row[pos++] = (uint8_t)(((c >> 5) & 0x3F) << 2);
            row[pos++] = (uint8_t)((c >> 11) << 3);
        }
        while (pos % 4 != 0) row[pos++] = 0;
        f.write(row, rowSize);
    }
    free(row);
    f.close();

    strncpy(s_lastPath, path, sizeof(s_lastPath) - 1);
    s_lastPath[sizeof(s_lastPath) - 1] = '\0';
    return s_lastPath;
}

}  // namespace paperemu_ui
